package docgenerator;

import com.opencsv.CSVReader;
import dto.clear.ClearProperty;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by xyzer on 9/29/2018.
 */
public class CsvParser {

    private static String csvPath = "src\\main\\resources\\sample.csv";

    CSVReader reader;

    public ArrayList<ClearProperty> csvToProperty(){

        ArrayList<ClearProperty> propertyInfo = new ArrayList<ClearProperty>();

        try {
            reader = new CSVReader(new FileReader(csvPath));
            String[] attribute;
            while ((attribute = reader.readNext()) != null) {
                propertyInfo.add(new ClearProperty(attribute[0],attribute[1],attribute[2],attribute[3],attribute[4]));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return propertyInfo;
    }
}

