package docgenerator;

import client.CrexiAssetClient;
import dto.crexi.AssetArrayDTO;
import dto.crexi.PropertyDTO;
import dto.crexi.UserData;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class CsvGenerator {

    PrintWriter printWriter;
    StringBuilder sb;

    public CsvGenerator() {
        sb = new StringBuilder();
        sb.append("Name of the property");
        sb.append(",");
        sb.append("Property URL");
        sb.append(",");
        sb.append("Name of Vistor");
        sb.append(',');
        sb.append("Email");
        sb.append(',');
        sb.append("Last Visited On");
        sb.append(',');
        sb.append("Number of Visits");
        sb.append(',');
        sb.append("industryRoles");
        sb.append(',');
        sb.append("Location");
        sb.append(',');
        sb.append("Phone");
        sb.append(',');
        sb.append("Company Name");
        sb.append('\n');
    }

    public void generateCsv(PropertyDTO assetName, ArrayList<UserData> vistors) throws FileNotFoundException {

        for (UserData user : vistors) {
            sb.append(assetName.getName());
            sb.append(',');
            sb.append("https://www.crexi.com/properties/" + assetName.getId());
            sb.append(',');
            sb.append(user.getUser().getFirstName() + " " + user.getUser().getLastName());
            sb.append(',');
            sb.append(user.getUser().getEmail());
            sb.append(',');
            sb.append(user.getLastTimeVisitedOn());
            sb.append(',');
            sb.append(user.getNumberOfVisits());
            sb.append(',');
            sb.append(user.getUser().getIndustryRoles().toString().replace(",", "+"));
            sb.append(',');
            try {
                sb.append(user.getUser().getLocation().replace(",", "-"));
            } catch (NullPointerException e) {
                sb.append(user.getUser().getLocation());
            }
            sb.append(',');
            sb.append(user.getUser().getPhone());
            sb.append(',');
            try {
                sb.append(user.getUser().getCompanyName().replace(",", " "));
            } catch (NullPointerException e) {
                sb.append(user.getUser().getCompanyName());
            }
            sb.append('\n');
        }
    }

    public void generateCsv(ArrayList<PropertyDTO> properties, ArrayList<UserData> vistors) throws FileNotFoundException {
        for(PropertyDTO assetName: properties){
            generateCsv(assetName,vistors);
        }
        printIt();
    }

    public void printIt() throws  FileNotFoundException{
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy_HH_mm_ss");
        Date date = new Date();
        String fileName = "_VISITOR_REPORT" + "_" + dateFormat.format(date);
        printWriter = new PrintWriter(new File(fileName + ".csv"));
        printWriter.write(sb.toString());
        printWriter.close();
    }
}
