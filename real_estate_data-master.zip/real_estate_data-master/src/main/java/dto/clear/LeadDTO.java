package dto.clear;

/**
 * Created by xyzer on 9/28/2018.
 */
public class LeadDTO {

    private String ownerName;
    private String ownerPhone;

    private String ownerContact;

    private String businessAddress;
    private String businessState;
    private String businessCity;

    private String ownerAddress;
    private String ownerCityStateZip;


    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getOwnerPhone() {
        return ownerPhone;
    }

    public void setOwnerPhone(String ownerPhone) {
        this.ownerPhone = ownerPhone;
    }

    public String getOwnerContact() {
        return ownerContact;
    }

    public void setOwnerContact(String ownerContact) {
        this.ownerContact = ownerContact;
    }

    public String getBusinessAddress() {
        return businessAddress;
    }

    public void setBusinessAddress(String businessAddress) {
        this.businessAddress = businessAddress;
    }

    public String getBusinessState() {
        return businessState;
    }

    public void setBusinessState(String businessState) {
        this.businessState = businessState;
    }

    public String getBusinessCity() {
        return businessCity;
    }

    public void setBusinessCity(String businessCity) {
        this.businessCity = businessCity;
    }

    public String getOwnerAddress() {
        return ownerAddress;
    }

    public void setOwnerAddress(String ownerAddress) {
        this.ownerAddress = ownerAddress;
    }

    public String getOwnerCityStateZip() {
        return ownerCityStateZip;
    }

    public void setOwnerCityStateZip(String ownerCityStateZip) {
        this.ownerCityStateZip = ownerCityStateZip;
    }

}
