package dto.crexi;

import com.fasterxml.jackson.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
                "id",
        "is_valid",
        "street_line_1",
        "street_line_2",
        "city",
        "postal_code",
        "zip4",
        "state_code",
        "country_code",
        "lat_long",
        "is_active",
        "is_commercial",
        "is_forwarder",
        "delivery_point",
        "last_sale_date",
        "total_value",
        "owners",
        "current_residents",
        "warnings",
        "error"
})
public class ReverseAddressDTO {
}
