package dto.crexi;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "CompanyName",
        "CreatedOn",
        "Email",
        "FirstName",
        "Id",
        "IndustryRoles",
        "LastName",
        "Location",
        "Phone",
        "ThumbnailUrl",
        "UserHasAccess"
})
public class User {

    @JsonProperty("CompanyName")
    private String companyName;
    @JsonProperty("CreatedOn")
    private String createdOn;
    @JsonProperty("Email")
    private String email;
    @JsonProperty("FirstName")
    private String firstName;
    @JsonProperty("Id")
    private Integer id;
    @JsonProperty("IndustryRoles")
    private List<String> industryRoles = null;
    @JsonProperty("LastName")
    private String lastName;
    @JsonProperty("Location")
    private String location;
    @JsonProperty("Phone")
    private String phone;
    @JsonProperty("ThumbnailUrl")
    private String thumbnailUrl;
    @JsonProperty("UserHasAccess")
    private Boolean userHasAccess;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CompanyName")
    public String getCompanyName() {
        return companyName;
    }

    @JsonProperty("CompanyName")
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    @JsonProperty("CreatedOn")
    public String getCreatedOn() {
        return createdOn;
    }

    @JsonProperty("CreatedOn")
    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    @JsonProperty("Email")
    public String getEmail() {
        return email;
    }

    @JsonProperty("Email")
    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("FirstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("FirstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("Id")
    public Integer getId() {
        return id;
    }

    @JsonProperty("Id")
    public void setId(Integer id) {
        this.id = id;
    }

    @JsonProperty("IndustryRoles")
    public List<String> getIndustryRoles() {
        return industryRoles;
    }

    @JsonProperty("IndustryRoles")
    public void setIndustryRoles(List<String> industryRoles) {
        this.industryRoles = industryRoles;
    }

    @JsonProperty("LastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("LastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("Location")
    public String getLocation() {
        return location;
    }

    @JsonProperty("Location")
    public void setLocation(String location) {
        this.location = location;
    }

    @JsonProperty("Phone")
    public String getPhone() {
        return phone;
    }

    @JsonProperty("Phone")
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @JsonProperty("ThumbnailUrl")
    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    @JsonProperty("ThumbnailUrl")
    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }

    @JsonProperty("UserHasAccess")
    public Boolean getUserHasAccess() {
        return userHasAccess;
    }

    @JsonProperty("UserHasAccess")
    public void setUserHasAccess(Boolean userHasAccess) {
        this.userHasAccess = userHasAccess;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return "User{" +
                "companyName='" + companyName + '\'' +
                ", createdOn='" + createdOn + '\'' +
                ", email='" + email + '\'' +
                ", firstName='" + firstName + '\'' +
                ", id=" + id +
                ", industryRoles=" + industryRoles +
                ", lastName='" + lastName + '\'' +
                ", location='" + location + '\'' +
                ", phone='" + phone + '\'' +
                ", thumbnailUrl='" + thumbnailUrl + '\'' +
                ", userHasAccess=" + userHasAccess +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}
