package dto.crexi;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ExecutedCA",
        "FeeAgreementIsAvailable",
        "FirstTimeVisitedOn",
        "IsNew",
        "LastTimeVisitedOn",
        "NumberOfVisits",
        "User"
})
public class UserData {

    @JsonProperty("ExecutedCA")
    private Boolean executedCA;
    @JsonProperty("FeeAgreementIsAvailable")
    private Boolean feeAgreementIsAvailable;
    @JsonProperty("FirstTimeVisitedOn")
    private String firstTimeVisitedOn;
    @JsonProperty("IsNew")
    private Boolean isNew;
    @JsonProperty("LastTimeVisitedOn")
    private String lastTimeVisitedOn;
    @JsonProperty("NumberOfVisits")
    private Integer numberOfVisits;
    @JsonProperty("User")
    private User user;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ExecutedCA")
    public Boolean getExecutedCA() {
        return executedCA;
    }

    @JsonProperty("ExecutedCA")
    public void setExecutedCA(Boolean executedCA) {
        this.executedCA = executedCA;
    }

    @JsonProperty("FeeAgreementIsAvailable")
    public Boolean getFeeAgreementIsAvailable() {
        return feeAgreementIsAvailable;
    }

    @JsonProperty("FeeAgreementIsAvailable")
    public void setFeeAgreementIsAvailable(Boolean feeAgreementIsAvailable) {
        this.feeAgreementIsAvailable = feeAgreementIsAvailable;
    }

    @JsonProperty("FirstTimeVisitedOn")
    public String getFirstTimeVisitedOn() {
        return firstTimeVisitedOn;
    }

    @JsonProperty("FirstTimeVisitedOn")
    public void setFirstTimeVisitedOn(String firstTimeVisitedOn) {
        this.firstTimeVisitedOn = firstTimeVisitedOn;
    }

    @JsonProperty("IsNew")
    public Boolean getIsNew() {
        return isNew;
    }

    @JsonProperty("IsNew")
    public void setIsNew(Boolean isNew) {
        this.isNew = isNew;
    }

    @JsonProperty("LastTimeVisitedOn")
    public String getLastTimeVisitedOn() {
        return lastTimeVisitedOn;
    }

    @JsonProperty("LastTimeVisitedOn")
    public void setLastTimeVisitedOn(String lastTimeVisitedOn) {
        this.lastTimeVisitedOn = lastTimeVisitedOn;
    }

    @JsonProperty("NumberOfVisits")
    public Integer getNumberOfVisits() {
        return numberOfVisits;
    }

    @JsonProperty("NumberOfVisits")
    public void setNumberOfVisits(Integer numberOfVisits) {
        this.numberOfVisits = numberOfVisits;
    }

    @JsonProperty("User")
    public User getUser() {
        return user;
    }

    @JsonProperty("User")
    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String toString() {
        return "UserData{" +
                "executedCA=" + executedCA +
                ", feeAgreementIsAvailable=" + feeAgreementIsAvailable +
                ", firstTimeVisitedOn='" + firstTimeVisitedOn + '\'' +
                ", isNew=" + isNew +
                ", lastTimeVisitedOn='" + lastTimeVisitedOn + '\'' +
                ", numberOfVisits=" + numberOfVisits +
                ", user=" + user +
                ", additionalProperties=" + additionalProperties +
                '}';
    }
}
