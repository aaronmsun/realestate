package client;

public class WhitepagesClient extends AbstractClient {
}
