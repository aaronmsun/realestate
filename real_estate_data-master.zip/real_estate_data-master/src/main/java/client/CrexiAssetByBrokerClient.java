package client;

import RequestUtil.RequestUtilities;
import dto.crexi.AssetArrayDTO;
import dto.crexi.AssetVisitorData;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Optional;

/**
 * Created by xyzer on 9/23/2018.
 */
public class CrexiAssetByBrokerClient extends AbstractClient{

    public AssetVisitorData assetDto(int id, String auth) throws IOException{
        HttpResponse response = null;
        try {
            url = new URIBuilder("https://api.crexi.com/assets/"+id+"/visitors");
            HttpGet getCall = new HttpGet(url.build());
            getCall.addHeader("Authorization","Bearer "+auth);
            response = client.execute(getCall);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return objectMapper.readValue(RequestUtilities.parseResponse(response.getEntity().getContent()).toString(),AssetVisitorData.class);
    }

}
