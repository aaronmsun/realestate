package webdriver.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


/**
 * Created by xyzer on 9/27/2018.
 */

//TODO: Cleanup this class!

public class ClearSignIn extends ParentPage{

    public ClearSignIn(WebDriver driver){
        this.driver = driver;
    }

    private static final String userNameXpath = "//input[@name='Username']";
    private static final String passwordXpath = "//input[@name='Password']";
    private static final String signInXpath = "//button[@name='SignIn']";

    public void login() throws Exception{

        //LOGIN INFO
        //TODO: remove the name and password
        WebElement userName = getWebElement(userNameXpath);
        userName.sendKeys("database");

        WebElement password = getWebElement(passwordXpath);
        password.sendKeys("Michael17");

        WebElement signIn = getWebElement(signInXpath);
        signIn.click();

        //Answer Security Question
        WebElement answerSecurityQuestion = driver.findElement(By.xpath("//input[@id='securityQuestions']"));
        JavascriptExecutor executor = (JavascriptExecutor)driver;
        executor.executeScript("arguments[0].click();", answerSecurityQuestion);
        WebElement continueQ = driver.findElement(By.xpath("//button[@id='SignIn']"));
        continueQ.click();

        WebElement securityAnswer = driver.findElement(By.xpath("//input[@id='SecurityAnswer']"));
        securityAnswer.sendKeys("Honda");

        WebElement submitAnswer = driver.findElement(By.xpath("//button[@id='Continue']"));
        submitAnswer.click();

        Thread.sleep(2000);
        //Dropdowns
        WebElement glbDropdown = driver.findElement(By.xpath("//select[@name='permissableuseGLBListBox']"));
        WebElement glbSelection = driver.findElement(By.xpath("//option[@value='C']"));
        glbDropdown.click();
        Thread.sleep(1000);
        glbSelection.click();

        WebElement dppaDropdown = driver.findElement(By.xpath("//select[@name='permissableuseDPPAListBox']"));
        WebElement dppaOption = driver.findElement(By.xpath("//option[@value='0']"));
        dppaDropdown.click();
        Thread.sleep(1000);
        dppaOption.click();

        Thread.sleep(1000);
        WebElement votersDropdown = driver.findElement(By.xpath("//select[@name='permissableuseVoterListBox']"));
        WebElement votersOption = driver.findElement(By.xpath("//option[@value='7']"));
        votersDropdown.click();
        Thread.sleep(1000);
        votersOption.click();

        Thread.sleep(1000);
        WebElement submitButton2 = driver.findElement(By.xpath("//div[@class='clearButton clearButton_orange']"));
        submitButton2.click();
    }



}
