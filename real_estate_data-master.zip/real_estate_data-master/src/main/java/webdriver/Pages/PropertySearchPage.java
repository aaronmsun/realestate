package webdriver.Pages;

import dto.clear.AddressDTO;
import dto.clear.ClearProperty;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;


/**
 * Created by xyzer on 9/29/2018.
 */
public class PropertySearchPage extends ParentPage{

    private static String searchXpath = "//div[@id='Accessibility_srch']//a";
    private static String searchMenuProperty = "//td[@id='searchMenuProperty']";

    private static String searchAddress = "//input[@name='propertySearchAddress']";
    private static String searchCity = "//input[@name='propertySearchCity']";
    private static String searchBusiness = "//input[@name='propertySearchBusinessName']";
    private static String selectDropdown="//select[@name='propertySearchState']";

    private static String submitButton = "//div[@id='realproperty_searchbtn']";

    public PropertySearchPage(WebDriver driver){
        this.driver = driver;
    }

    public void navigateTo(){
        getWebElement(searchXpath).click();
        getWebElement(searchMenuProperty).click();
    }

    public void lookupAddress(AddressDTO address){
        getWebElement(searchAddress).sendKeys(address.getStreetAddress());
        getWebElement(searchCity).sendKeys(address.getCity());
        Select dropdown = new Select(getWebElement(selectDropdown));
        dropdown.selectByValue(address.getState());
        getWebElement(submitButton).click();
    }

    public void lookupBusinessProperty(ClearProperty property) throws Exception{
        navigateTo();
        getWebElement(searchBusiness).sendKeys(property.getBusinessName());
        getWebElement(searchAddress).sendKeys(property.getAddress());
        getWebElement(searchCity).sendKeys(property.getCity());
        Select dropdown = new Select(getWebElement(selectDropdown));
        dropdown.selectByValue(property.getState());
        getWebElement(submitButton).click();
        Thread.sleep(1500);
    }
}
