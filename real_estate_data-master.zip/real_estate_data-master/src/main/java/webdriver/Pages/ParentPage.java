package webdriver.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

/**
 * Created by xyzer on 9/28/2018.
 */
public class ParentPage {

    public WebDriver driver;

    public WebElement getWebElement(String xpath){
        return driver.findElement(By.xpath(xpath));
    }

}
