package webdriver;

import dto.clear.AddressDTO;
import dto.clear.ClearProperty;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import webdriver.Pages.ClearSignIn;
import webdriver.Pages.PropertySearchPage;

import java.util.ArrayList;

/**
 * Created by xyzer on 9/27/2018.
 */
public class DriverProvider {

    //TODO: clean this up: create a FeatureContext class to persist a session Webdriver
    public void init(ArrayList<ClearProperty> properties) throws Exception{
        String exePath = "/Users/jding/Documents/workspace/real_estate_data/src/main/resources/chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", exePath);
        WebDriver driver = new ChromeDriver();
        driver.get("");
        ClearSignIn page = new ClearSignIn(driver);
        page.login();
        PropertySearchPage page2 = new PropertySearchPage(driver);

        properties.forEach(ClearProperty -> {
            try {
                page2.lookupBusinessProperty(ClearProperty);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


    }

}
