import docgenerator.CsvParser;
import dto.clear.ClearProperty;
import org.junit.jupiter.api.Test;
import webdriver.DriverProvider;

import java.util.ArrayList;

/**
 * Created by xyzer on 9/29/2018.
 */
public class DemoIT {
    @Test
    public void testWebdriver() throws Exception{
        CsvParser parse = new CsvParser();
        ArrayList<ClearProperty> properties = parse.csvToProperty();
        DriverProvider driver = new DriverProvider();
        driver.init(properties);

    }
}
