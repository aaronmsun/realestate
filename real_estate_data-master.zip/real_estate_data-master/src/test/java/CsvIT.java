import docgenerator.CsvParser;
import dto.clear.ClearProperty;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

/**
 * Created by xyzer on 9/29/2018.
 */
public class CsvIT {

    @Test
    public void parseCsv(){
        CsvParser parse = new CsvParser();
        ArrayList<ClearProperty> properties = parse.csvToProperty();
        properties.forEach(ClearProperty -> System.out.println(ClearProperty.getBusinessName()));
    }

}
