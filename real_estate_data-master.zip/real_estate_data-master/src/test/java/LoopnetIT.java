import client.LoopNextClient;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.jupiter.api.Test;
import webdriver.DriverProvider;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

/**
 * Created by xyzer on 9/24/2018.
 */
public class LoopnetIT {

    LoopNextClient client = new LoopNextClient();

    @Test
    public void client() throws FileNotFoundException, IOException{
        BufferedReader br = new BufferedReader(new FileReader("./resources/test_json/loopnet_sample_outbound_payload.json"));
        JsonParser parser = new JsonParser();
        JsonObject json = parser.parse(br).getAsJsonObject();
        client.loopnetSearchDTO(new HashMap<String,String>(),json);
    }



}
